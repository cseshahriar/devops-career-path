# IC-DevOps-Batch3
Tasks, Assignments, Projects for IC DevOps Batch 3

## Do not change content of this file

## General Project/Assignment Submission Guideline
- Fork the repository
- Create a new branch
- Under the designated assignment/project folder create a directory with <your_name>-<IC_student_ID>
- Add a readme.md and .gitignore file in your directory
- Upload assignment content to your directory
- Create a pull request against the master branch from your forked repoed branch
- Add a description of the PR
